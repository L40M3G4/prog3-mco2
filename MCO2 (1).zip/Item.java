import java.util.Objects;

public class Item {
    private String name;
    private float calorieCount;
    private float price;
    private boolean unique;
    private int quantity;

    public Item() {
        this.name = "";
        this.calorieCount = 0;
        this.price = 0;
        this.unique = true;
        this.quantity = 0;
    }

    public Item(String name, float calorieCount, float price) {
        this.name = name;
        this.calorieCount = calorieCount;
        this.price = price;
        this.unique = true;
        this.quantity = 0;
    }

    public String getItemName() {
        return name;
    }

    public void setItemName(String name) {
        this.name = name;
    }

    public float getCalorieCount() {
        return calorieCount;
    }

    public void setCalorieCount(float calorieCount) {
        this.calorieCount = calorieCount;
    }

    public boolean isUnique() {
        return unique;
    }

    public void setUnique(boolean unique) {
        this.unique = unique;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Item item = (Item) obj;
        return Objects.equals(name, item.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
