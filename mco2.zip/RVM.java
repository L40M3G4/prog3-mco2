import javax.swing.JTextArea;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RVM {

    private Slot[] slots;
    private int capacity;
    private int totalItems;
    private float money;
    private float totalSales;
    private ArrayList<Transaction> transactions = new ArrayList<>();
    private List<Item> userPurchased = new ArrayList<>();

    public RVM(int capacity) {
        this.capacity = capacity;
        slots = new Slot[capacity];
        this.money = 100000;
        for (int i = 0; i < capacity; i++) {
            slots[i] = new Slot(10);
        }
    }

    public void addItem(Item item, int capacity, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        if (totalItems < capacity * 10) {
            for (int i = 0; i < slots.length; i++) {
                if (slots[i].getItems() == null) {
                    display.append("Adding item..." + "\n");
                    slots[i].setItems(item);
                    slots[i].setQuantity(capacity, displayArea);
                    totalItems++;
                    display.append("Item added." + "\n");
                    return;
                }
            }
        }

        displayArea.setText(display.toString());

    }

    public void setItem(Item item, int capacity, JTextArea displayArea) {
        if (totalItems < capacity * 10) {
            for (int i = 0; i < slots.length; i++) {
                if (slots[i].getItems() == null) {
                    slots[i].setItems(item);
                    slots[i].setQuantity(capacity, displayArea);
                    totalItems++;
                    return;
                }
            }
        }
    }

    public void deleteItem(Item item, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        for (int i = 0; i < slots.length; i++) {
            if (slots[i].getItems() != null && slots[i].getItems().equals(item)) {
                display.append("Deleting item..." + "\n");
                slots[i].setItems(null);
                slots[i].setQuantity(0, displayArea);
                totalItems--;
                display.append("Item deleted." + "\n");
                return;
            }
        }

        displayArea.setText(display.toString());
    }

    public void displayItem(String itemName, JTextArea displayArea) {
        Item itemToDisplay = null;

        for (Slot slot : slots) {
            Item item = slot.getItems();
            if (item != null && item.getItemName().equals(itemName)) {
                itemToDisplay = item;
                break;
            }
        }

        if (itemToDisplay == null) {
            displayArea.setText("Item not found: " + itemName);
        } else {
            StringBuilder itemz = new StringBuilder();
            itemz.append("ITEM\t:   " + itemToDisplay.getItemName() + "\n");
            itemz.append("PRICE\t:   " + itemToDisplay.getPrice() + "\n");
            itemz.append("CALORIES\t:   " + itemToDisplay.getCalorieCount() + "\n");

            // Get the quantity of the item from the corresponding slot
            int quantity = getItemQuantity(itemToDisplay);
            itemz.append("QUANTITY\t:   " + quantity + "\n");
            itemz.append("------------------------");

            displayArea.setText(itemz.toString());
        }
    }

    private int getItemQuantity(Item item) {
        for (Slot slot : slots) {
            if (slot.getItems() == item) {
                return slot.getQuantity();
            }
        }
        return 0;
    }

    public void displayInventory(JTextArea displayArea) {
        StringBuilder inventory = new StringBuilder();
        inventory.append("Starting Inventory:\n");
        for (int i = 0; i < slots.length; i++) {
            Item item = slots[i].getItems();
            if (item != null) {
                inventory.append("Item: " + item.getItemName() + ", Quantity: " + slots[i].getQuantity() + "\n");
            }
        }

        inventory.append("\n");

        inventory.append("Ending Inventory:\n");
        for (int i = 0; i < slots.length; i++) {
            Item item = slots[i].getItems();
            if (item != null) {
                inventory.append("Item: " + item.getItemName() + ", Quantity: " + slots[i].getQuantity() + "\n");
            }

            displayArea.setText(inventory.toString());

        }
    }

    public void setUserPurchased(List<Item> userPurchased)
    {
        this.userPurchased = userPurchased;
    }

    public List<Item> getUserPurchased()
    {
        return userPurchased;
    }


    public void buyItem(String itemName, float payment, int quantity, JTextArea displayArea) {
        StringBuilder bItem = new StringBuilder();

        Item itemToDisplay = null;

        for (Slot slot : slots) {
            Item item = slot.getItems();
            if (item != null && item.getItemName().equals(itemName)) {
                itemToDisplay = item;
                break;
            }
        }

        for (int i = 0; i < slots.length; i++) {
            Item item = slots[i].getItems();
            if (item != null && item.getItemName().equals(itemName)) {
                float price = item.getPrice();
                if (slots[i].getQuantity() >= quantity && payment >= price * quantity) {
                    bItem.append("\nItem purchased: " + item.getItemName() + "\n");
                    float change = payment - (price * quantity);
                    getChange(change, displayArea);
                    totalSales += (price * quantity);
                    slots[i].decrementQuantity(quantity, displayArea);

                    for (int j = 0; j < quantity; j++) {
                        userPurchased.add(item);
                    }

                    Transaction transaction = new Transaction(createID(), item, quantity, payment, change);
                    transactions.add(transaction);
                } else {
                    if (slots[i].getQuantity() < quantity) {
                        bItem.append("Insufficient quantity for item: " + item.getItemName() + "\n");
                    } else {
                        bItem.append("Insufficient payment for item: " + item.getItemName() + "\n");
                        bItem.append("Please insert additional payment of: " + ((price * quantity) - payment) + "\n");
                    }
                }
                break;
            }
        }

        if (itemToDisplay == null) {
            bItem.append("Item not found: " + itemName + "\n");
        }

        displayArea.append(bItem.toString());
    }





    public void getChange(float change, JTextArea displayArea) {
        StringBuilder changeT = new StringBuilder();

        if (change > money) {
            changeT.append("Insufficient change available. Please contact maintenance." + "\n");
            return;
        }

        int pesos = (int) change;
        int centavos = Math.round((change - pesos) * 100);

        changeT.append("\nChange: " + pesos + " pesos");

        if (centavos > 0) {
            changeT.append(centavos + " centavos");
        }

        money -= change;
        displayArea.append(changeT.toString());


    }


    public void collectMoney(float amount, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        money += amount;
        display.append("Money collected: " + amount + "\n");

        displayArea.setText(display.toString());
    }

    public void replenishMoney(float amount, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        money += amount;
        display.append("Money replenished: " + amount + "\n");

        displayArea.setText(display.toString());
    }

    public void printTransactions(JTextArea displayArea) {

        StringBuilder transact = new StringBuilder();

        for (Transaction transaction : transactions) {
            transact.append("TRANSACTION ID\t:   " + transaction.getID() + "\n");
            transact.append("ITEM PURCHASED\t:   " + transaction.getItem().getItemName() + "\n");
            transact.append("QUANTITY\t:   " + transaction.getQuantity()+ "\n");
            transact.append("PAYMENT\t:   P" + transaction.getPayment() + "\n");
            transact.append("CHANGE\t:   P" + transaction.getChange() + "\n");
            transact.append("------------------------\n");

            displayArea.setText(transact.toString());

        }
    }


    public float printSales() {
        return totalSales;
    }

    public Slot[] getSlots() {
        return slots;
    }

    private int createID() {
        Random rand = new Random();
        int transactionId = rand.nextInt(100000) + 1;
        return transactionId;
    }
}
