import javax.swing.JTextArea;

public class Maintenance {
    private RVM vending;
    public Maintenance(RVM vending) {
        this.vending = vending;
    }

    public void restockItems(String itemName, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        boolean itemFound = false;

        for (int i = 0; i < vending.getSlots().length; i++) {
            Slot slot = vending.getSlots()[i];
            Item item = slot.getItems();

            if (item != null && item.getItemName().equals(itemName)) {
                slot.setQuantity(10, displayArea);
                itemFound = true;
                break;
            }
        }

        if (itemFound) {
            display.append("Item restocked: " + itemName + "\n");
        } else {
            display.append("Item not found!" + "\n");
        }

        displayArea.setText(display.toString());

    }

    public void setPrice(Item item, float price, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();


        item.setPrice(price);
        display.append("Item: " + item.getItemName() + " - Price: " + price + "\n");

        displayArea.setText(display.toString());

    }

    public void collectMoney(float amount, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        vending.collectMoney(amount, displayArea);
        display.append("Money collected: " + amount + "\n");

        displayArea.setText(display.toString());
    }

    public void replenishMoney(float amount,  JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        vending.replenishMoney(amount, displayArea);
        display.append("Money replenished: " + amount + "\n");

        displayArea.setText(display.toString());

    }
}
