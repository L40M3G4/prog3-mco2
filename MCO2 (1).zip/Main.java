import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;


public class Main {
    static int vmType = 0;
    static int itemType_reg = 0;
    static int itemType_spc = 0;
    static int quantity_items = 0;
    static int quantity_money = 0;
    static RVM vendingMachine = null;
    static SVM specialVendingMachine = null;
    static Maintenance regular = new Maintenance(vendingMachine);
    static SpecialMaintenance special = new SpecialMaintenance(specialVendingMachine);
    static int wallet = 0;

    public static void main(String[] args) {
        gui();

    }

    private static void gui() {

        //===============Main Menu View========================

        JFrame mainMenu = new JFrame("Main Menu");
        mainMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainMenu.setSize(1920, 1800); // Set a reasonable initial size
        Color mm_color = new Color(30, 30, 30);
        Color buttons_color = new Color(250, 250, 250);
        Font buttonFont = new Font("EFour Digital Pro", Font.PLAIN, 20);
        mainMenu.getContentPane().setBackground(mm_color);
        mainMenu.setLayout(new FlowLayout());

        //"C:\\school-prog-files\\elements\\rvm-drawing.png"

        JPanel left = new JPanel(new GridBagLayout()); //contains rvm drawing and button
        JPanel right = new JPanel(new GridBagLayout()); //contains svm drawing and button
        JPanel center = new JPanel(new GridBagLayout()); //contains 3 buttons::create, maintain, test

        left.setBackground(mm_color);
        left.setPreferredSize(new Dimension(450, 1800));
        center.setBackground(mm_color);
        center.setPreferredSize(new Dimension(300, 1800));
        right.setBackground(mm_color);
        right.setPreferredSize(new Dimension(450, 1800));


        //adding ze eemeges and ze boottons
        //left

        String rvm_path = "C:\\school-prog-files\\elements\\rvm-drawing.png";
        ImageIcon rvmImage = new ImageIcon(rvm_path);
        Image ogrvmImage = rvmImage.getImage();
        Image rvmResized = ogrvmImage.getScaledInstance(300, 500, Image.SCALE_SMOOTH);
        ImageIcon resizedrvm = new ImageIcon(rvmResized);
        JLabel rvm_label = new JLabel(resizedrvm);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(-1150, 0, 0, 0);
        gbc.gridy = 0;
        left.add(rvm_label, gbc);
        /*
         * mic test, test mic, testing mic, micing test, mic mic test test, test test mic mic
         * */

        gbc.insets = new Insets(-600, 0, 0, 0);
        gbc.gridy = 1;
        JButton rvmButton = new JButton("Choose me"); //pIcK mE lOvE mE - Meredith Grey
        rvmButton.setBackground(buttons_color);
        rvmButton.setPreferredSize(new Dimension(160, 30));
        rvmButton.setFont(buttonFont);

        left.add(rvmButton, gbc);


        //center

        JButton create = new JButton("CREATE");
        create.setPreferredSize(new Dimension(200, 50));
        JButton test = new JButton("TEST");
        test.setPreferredSize(new Dimension(200, 50));
        JButton maintain = new JButton("MAINTAIN");
        maintain.setPreferredSize(new Dimension(200, 50));

        create.setBackground(buttons_color);
        create.setFont(buttonFont);
        test.setBackground(buttons_color);
        test.setFont(buttonFont);
        maintain.setBackground(buttons_color);
        maintain.setFont(buttonFont);

        gbc.insets = new Insets(-1250, 0, 0, 0);
        gbc.gridy = 0;
        center.add(create, gbc);
        gbc.insets = new Insets(-1130, 0, 0, 0);
        gbc.gridy = 1;
        center.add(test, gbc);
        gbc.insets = new Insets(-1010, 0, 0, 0);
        gbc.gridy = 2;
        center.add(maintain, gbc);

        //right
        String svm_path = "C:\\school-prog-files\\elements\\svm-drawing.png";
        ImageIcon svmImage = new ImageIcon(svm_path);
        Image ogsvmImage = svmImage.getImage();
        Image svmResized = ogsvmImage.getScaledInstance(300, 500, Image.SCALE_SMOOTH);
        ImageIcon resizedsvm = new ImageIcon(svmResized);
        JLabel svm_label = new JLabel(resizedsvm);
        gbc.insets = new Insets(-1150, 0, 0, 0);
        gbc.gridy = 0;
        right.add(svm_label, gbc);

        gbc.insets = new Insets(-600, 0, 0, 0);
        gbc.gridy = 1;
        JButton svmButton = new JButton("Choose me"); //pIcK mE lOvE mE - Meredith Grey
        svmButton.setBackground(buttons_color);
        svmButton.setPreferredSize(new Dimension(160, 30));
        svmButton.setFont(buttonFont);

        right.add(svmButton, gbc);

        //-----------------------------------------------------------------
        //===================BASIC-BUY VIEW===============================

        JFrame basic_buy = new JFrame("Testing");
        basic_buy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        basic_buy.setSize(1920, 1800); // Set a reasonable initial size
        /*
         * Color mm_color = new Color(30,30,30);
         * Color buttons_color = new Color(250,250,250);
         * Font buttonFont = new Font("EFour Digital Pro", Font.PLAIN, 20);
         * */

        basic_buy.getContentPane().setBackground(mm_color);
        basic_buy.setLayout(new FlowLayout());

        //"C:\\school-prog-files\\elements

        JPanel leftbb = new JPanel(new GridBagLayout()); //contains rvm drawing and button
        JPanel centerbb = new JPanel(/*new GridBagLayout()*/); //contains svm drawing and button
        JPanel rightbb = new JPanel(new GridBagLayout()); //contains 3 buttons::create, maintain, test

        leftbb.setBackground(mm_color);
        leftbb.setPreferredSize(new Dimension(250, 1800));
        centerbb.setBackground(mm_color);
        centerbb.setPreferredSize(new Dimension(500, 1800));
        rightbb.setBackground(mm_color);
        rightbb.setPreferredSize(new Dimension(250, 1800));


        //getting the image element

        String both_path = "C:\\school-prog-files\\elements\\bothVMS.png";
        ImageIcon bothImage = new ImageIcon(both_path);
        Image ogbothImage = bothImage.getImage();
        Image bothResized = ogbothImage.getScaledInstance(250, 350, Image.SCALE_SMOOTH);
        ImageIcon resizedboth = new ImageIcon(bothResized);
        JLabel both_label = new JLabel(resizedboth);

        GridBagConstraints gbc_bb = new GridBagConstraints();
        gbc_bb.gridx = 0;
        gbc_bb.anchor = GridBagConstraints.CENTER;
        gbc_bb.insets = new Insets(-1300, 0, 0, 0);
        gbc_bb.gridy = 0;
        leftbb.add(both_label, gbc_bb);

        gbc_bb.insets = new Insets(-600, 0, 0, 0);
        gbc_bb.gridy = 1;
        JButton back_bb = new JButton("Back");
        back_bb.setBackground(buttons_color);
        back_bb.setPreferredSize(new Dimension(160, 30));
        back_bb.setFont(buttonFont);
        leftbb.add(back_bb, gbc_bb);

        centerbb.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel center1 = new JPanel();
        center1.setBorder(null);
        center1.setPreferredSize(new Dimension(200, 550));
        center1.setBackground(mm_color);
        JPanel center2 = new JPanel();
        centerbb.setLayout(new FlowLayout());
        center1.setLayout(new GridLayout(4, 2, 5, 15));
        center2.setLayout(new GridLayout(2, 1, 10, 50));
        center2.setPreferredSize(new Dimension(250, 600));


        //for center 1
        ImageIcon carrot = new ImageIcon("C:\\school-prog-files\\elements\\carrots1.png");
        JButton slot1 = new JButton(carrot);
        slot1.setPreferredSize(new Dimension(100, 100));
        slot1.setText(null);
        slot1.setBorderPainted(false);
        slot1.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot1.setBackground(mm_color);
        center1.add(slot1);

        ImageIcon mushroom = new ImageIcon("C:\\school-prog-files\\elements\\mushroom.png");
        JButton slot2 = new JButton(mushroom);
        slot2.setPreferredSize(new Dimension(100, 50));
        slot2.setText(null);
        slot2.setBorderPainted(false);
        slot2.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot2.setBackground(mm_color);
        center1.add(slot2);


        ImageIcon broccoli = new ImageIcon("C:\\school-prog-files\\elements\\broccoli.png");
        JButton slot3 = new JButton(broccoli);
        slot3.setPreferredSize(new Dimension(100, 100));
        slot3.setText(null);
        slot3.setBorderPainted(false);
        slot3.setBorder(null);
        slot3.setBackground(mm_color);
        center1.add(slot3);

        ImageIcon bitterGourd = new ImageIcon("C:\\school-prog-files\\elements\\bitterGourd.png");
        JButton slot4 = new JButton(bitterGourd);
        slot4.setPreferredSize(new Dimension(100, 100));
        slot4.setText(null);
        slot4.setBorderPainted(false);
        slot4.setBorder(null);
        slot4.setBackground(mm_color);
        center1.add(slot4);

        ImageIcon anchovy = new ImageIcon("C:\\school-prog-files\\elements\\anchovy.png");
        JButton slot5 = new JButton(anchovy);
        slot5.setPreferredSize(new Dimension(100, 100));
        slot5.setText(null);
        slot5.setBorderPainted(false);
        slot5.setBorder(null);
        slot5.setBackground(mm_color);
        center1.add(slot5);


        ImageIcon rice = new ImageIcon("C:\\school-prog-files\\elements\\rice.png");
        JButton slot6 = new JButton(rice);
        slot6.setPreferredSize(new Dimension(100, 100));
        slot6.setText(null);
        slot6.setBorderPainted(false);
        slot6.setBackground(mm_color);
        slot6.setBorder(null);
        center1.add(slot6);

        ImageIcon squash = new ImageIcon("C:\\school-prog-files\\elements\\squash.png");
        JButton slot7 = new JButton(squash);
        slot7.setPreferredSize(new Dimension(100, 100));
        slot7.setText(null);
        slot7.setBorderPainted(false);
        slot7.setBorder(null);
        slot7.setBackground(mm_color);
        center1.add(slot7);

        ImageIcon tomato = new ImageIcon("C:\\school-prog-files\\elements\\tomato.png");
        JButton slot8 = new JButton(tomato);
        slot8.setPreferredSize(new Dimension(100, 100));
        slot8.setText(null);
        slot8.setBorderPainted(false);
        slot8.setBorder(null);
        slot8.setBackground(mm_color);
        center1.add(slot8);


        //for center 2
        JTextArea display_bb = new JTextArea();
        JTextArea total_due = new JTextArea();
        display_bb.setPreferredSize(new Dimension(250, 500));
        display_bb.setLineWrap(true);
        display_bb.setWrapStyleWord(true);
        total_due.setPreferredSize(new Dimension(250, 50));
        display_bb.setEditable(false);
        total_due.setEditable(false);

        center2.add(display_bb);
        center2.add(total_due);

        centerbb.add(center1);
        centerbb.add(center2);

        rightbb.setLayout(new FlowLayout(FlowLayout.CENTER, 70, 10));


        JPanel top = new JPanel();
        top.setPreferredSize(new Dimension(200, 50));
        JPanel mid = new JPanel();
        mid.setLayout(new GridLayout(2, 3));
        JPanel bottom = new JPanel();

        JLabel PayMe = new JLabel("Pay amount");
        PayMe.setFont(buttonFont);
        top.add(PayMe);

        JButton bente = new JButton("20");
        JButton pipty = new JButton("50");
        JButton wanhandred = new JButton("100");
        JButton fortune500 = new JButton("500");
        JButton oneGrand = new JButton("1000");

        bente.setBackground(buttons_color);
        pipty.setBackground(buttons_color);
        wanhandred.setBackground(buttons_color);
        fortune500.setBackground(buttons_color);
        oneGrand.setBackground(buttons_color);

        bente.setFont(buttonFont);
        pipty.setFont(buttonFont);
        wanhandred.setFont(buttonFont);
        fortune500.setFont(buttonFont);
        oneGrand.setFont(buttonFont);

        mid.add(bente);
        mid.add(pipty);
        mid.add(wanhandred);
        mid.add(fortune500);
        mid.add(oneGrand);

        bottom.setLayout(new GridLayout(5, 1, 0, 20));
        bottom.setPreferredSize(new Dimension(250, 500));
        JButton clearMoolah = new JButton("CLEAR MONEY");
        clearMoolah.setFont(buttonFont);
        clearMoolah.setBackground(buttons_color);
        bottom.add(clearMoolah);

        JButton displayInventory = new JButton("INVENTORY");
        displayInventory.setFont(buttonFont);
        displayInventory.setBackground(buttons_color);
        bottom.add(displayInventory);

        JButton pastGastos = new JButton(" PAST TRANSACTIONS");
        pastGastos.setFont(buttonFont);
        pastGastos.setBackground(buttons_color);
        bottom.add(pastGastos);

        JButton specialMenu = new JButton("EXTRA ITEMS");
        specialMenu.setFont(buttonFont);
        specialMenu.setBackground(buttons_color);
        bottom.add(specialMenu);

        JButton checkout = new JButton("CHECKOUT");
        checkout.setFont(buttonFont);
        checkout.setBackground(buttons_color);
        bottom.add(checkout);


        rightbb.add(top);
        rightbb.add(mid);
        rightbb.add(bottom);
        //-----------------------------------------------------------------
        //-----------------------------------------------------------------
        //===================SVM ADDITIONAL VIEW ( SAV )===============================


        JFrame special_buy = new JFrame("Special");
        special_buy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        special_buy.setSize(1920, 1800); // Set a reasonable initial size
        /*
         * Color mm_color = new Color(30,30,30);
         * Color buttons_color = new Color(250,250,250);
         * Font buttonFont = new Font("EFour Digital Pro", Font.PLAIN, 20);
         * */

        special_buy.getContentPane().setBackground(mm_color);
        special_buy.setLayout(new FlowLayout());

        //"C:\\school-prog-files\\elements

        JPanel lefts = new JPanel(new GridBagLayout()); //contains rvm drawing and button
        JPanel centers = new JPanel(/*new GridBagLayout()*/); //contains svm drawing and button
        JPanel rights = new JPanel(new GridBagLayout()); //contains 3 buttons::create, maintain, test

        lefts.setBackground(mm_color);
        lefts.setPreferredSize(new Dimension(250, 1800));
        centers.setBackground(mm_color);
        centers.setPreferredSize(new Dimension(500, 1800));
        rights.setBackground(mm_color);
        rights.setPreferredSize(new Dimension(250, 1800));


        //getting the image element

        String both1_path = "C:\\school-prog-files\\elements\\bothVMS.png";
        ImageIcon both1Image = new ImageIcon(both1_path);
        Image ogboth1Image = both1Image.getImage();
        Image both1Resized = ogboth1Image.getScaledInstance(250, 350, Image.SCALE_SMOOTH);
        ImageIcon resizedboth1 = new ImageIcon(both1Resized);
        JLabel both1_label = new JLabel(resizedboth1);

        GridBagConstraints gbc_s = new GridBagConstraints();
        gbc_s.gridx = 0;
        gbc_s.anchor = GridBagConstraints.CENTER;
        gbc_s.insets = new Insets(-1300, 0, 0, 0);
        gbc_s.gridy = 0;
        lefts.add(both1_label, gbc_s);

        gbc_s.insets = new Insets(-600, 0, 0, 0);
        gbc_s.gridy = 1;
        JButton back_s = new JButton("Back");
        back_s.setBackground(buttons_color);
        back_s.setPreferredSize(new Dimension(160, 30));
        back_s.setFont(buttonFont);
        lefts.add(back_s, gbc_s);

        centers.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel center11 = new JPanel();
        center11.setBorder(null);
        center11.setPreferredSize(new Dimension(200, 550));
        center11.setBackground(mm_color);
        JPanel center22 = new JPanel();
        centers.setLayout(new FlowLayout());
        center11.setLayout(new GridLayout(4, 2, 5, 15));
        center22.setLayout(new GridLayout(2, 1, 10, 50));
        center22.setPreferredSize(new Dimension(250, 600));


        //for center 1
        ImageIcon FriRi = new ImageIcon("C:\\school-prog-files\\elements\\carrots1.png");
        JButton slot11 = new JButton(FriRi);
        slot11.setPreferredSize(new Dimension(100, 100));
        slot11.setText(null);
        slot11.setBorderPainted(false);
        slot11.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot11.setBackground(mm_color);
        center11.add(slot11);

        ImageIcon ARB = new ImageIcon("C:\\school-prog-files\\elements\\mushroom.png");
        JButton slot22 = new JButton(ARB);
        slot22.setPreferredSize(new Dimension(100, 50));
        slot22.setText(null);
        slot22.setBorderPainted(false);
        slot22.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot22.setBackground(mm_color);
        center11.add(slot22);


        ImageIcon SRB = new ImageIcon("C:\\school-prog-files\\elements\\broccoli.png");
        JButton slot33 = new JButton(SRB);
        slot33.setPreferredSize(new Dimension(100, 100));
        slot33.setText(null);
        slot33.setBorderPainted(false);
        slot33.setBorder(null);
        slot33.setBackground(mm_color);
        center11.add(slot33);

        ImageIcon SSR = new ImageIcon("C:\\school-prog-files\\elements\\bitterGourd.png");
        JButton slot44 = new JButton(SSR);
        slot44.setPreferredSize(new Dimension(100, 100));
        slot44.setText(null);
        slot44.setBorderPainted(false);
        slot44.setBorder(null);
        slot44.setBackground(mm_color);
        center11.add(slot44);

        ImageIcon TRS = new ImageIcon("C:\\school-prog-files\\elements\\anchovy.png");
        JButton slot55 = new JButton(TRS);
        slot55.setPreferredSize(new Dimension(100, 100));
        slot55.setText(null);
        slot55.setBorderPainted(false);
        slot55.setBorder(null);
        slot55.setBackground(mm_color);
        center11.add(slot55);


        ImageIcon SAFR = new ImageIcon("C:\\school-prog-files\\elements\\rice.png");
        JButton slot66 = new JButton(SAFR);
        slot66.setPreferredSize(new Dimension(100, 100));
        slot66.setText(null);
        slot66.setBorderPainted(false);
        slot66.setBackground(mm_color);
        slot66.setBorder(null);
        center11.add(slot66);

        ImageIcon MRS = new ImageIcon("C:\\school-prog-files\\elements\\squash.png");
        JButton slot77 = new JButton(MRS);
        slot77.setPreferredSize(new Dimension(100, 100));
        slot77.setText(null);
        slot77.setBorderPainted(false);
        slot77.setBorder(null);
        slot77.setBackground(mm_color);
        center11.add(slot77);

        ImageIcon BAT = new ImageIcon("C:\\school-prog-files\\elements\\tomato.png");
        JButton slot88 = new JButton(BAT);
        slot88.setPreferredSize(new Dimension(100, 100));
        slot88.setText(null);
        slot88.setBorderPainted(false);
        slot88.setBorder(null);
        slot88.setBackground(mm_color);
        center11.add(slot88);


        //for center 2
        JTextArea display_s = new JTextArea();
        JTextArea total_due_s = new JTextArea();
        display_s.setPreferredSize(new Dimension(250, 500));
        total_due_s.setPreferredSize(new Dimension(250, 50));
        display_s.setWrapStyleWord(true);
        display_s.setLineWrap(true);
        display_s.setEditable(false);
        total_due_s.setEditable(false);

        center22.add(display_s);
        center22.add(total_due_s);

        centers.add(center11);
        centers.add(center22);

        rights.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));


        JPanel top_s = new JPanel();
        top_s.setPreferredSize(new Dimension(200, 50));
        JPanel mid_s = new JPanel();
        mid_s.setLayout(new GridLayout(2, 3));
        JPanel bottom_s = new JPanel();

        JLabel PayMe_s = new JLabel("SPECIAL");
        PayMe_s.setFont(buttonFont);
        top_s.add(PayMe_s);


        bottom_s.setLayout(new GridLayout(5, 1, 0, 20));
        bottom_s.setPreferredSize(new Dimension(250, 500));
        JButton clearChoices_s = new JButton("CLEAR CHOICES");
        clearChoices_s.setFont(buttonFont);
        clearChoices_s.setBackground(buttons_color);
        bottom_s.add(clearChoices_s);

        JButton displayInventory_s = new JButton("INVENTORY");
        displayInventory_s.setFont(buttonFont);
        displayInventory_s.setBackground(buttons_color);
        bottom_s.add(displayInventory_s);

        JButton pastGastos_s = new JButton(" PAST TRANSACTIONS");
        pastGastos_s.setFont(buttonFont);
        pastGastos_s.setBackground(buttons_color);
        bottom_s.add(pastGastos_s);

        JButton available_s = new JButton("AVAILABLE");
        available_s.setFont(buttonFont);
        available_s.setBackground(buttons_color);
        bottom_s.add(available_s);

        JButton checkout_s = new JButton("CHECKOUT");
        checkout_s.setFont(buttonFont);
        checkout_s.setBackground(buttons_color);
        bottom_s.add(checkout_s);


        rights.add(top_s);
        rights.add(mid_s);
        rights.add(bottom_s);


        //-----------------------------------------------------------------
        //-----------------------------------------------------------------
        //===================MAINTAIN VIEW RVM===============================

        JFrame rvm_main = new JFrame("RVM Maintenance");
        rvm_main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        rvm_main.setSize(1920, 1800); // Set a reasonable initial size
        /*
         * Color mm_color = new Color(30,30,30);
         * Color buttons_color = new Color(250,250,250);
         * Font buttonFont = new Font("EFour Digital Pro", Font.PLAIN, 20);
         * */

        rvm_main.getContentPane().setBackground(mm_color);
        rvm_main.setLayout(new FlowLayout());

        //"C:\\school-prog-files\\elements

        JPanel left_RM = new JPanel(new GridBagLayout()); //contains rvm drawing and button
        JPanel center_RM = new JPanel(/*new GridBagLayout()*/); //contains svm drawing and button
        JPanel right_RM = new JPanel(new GridBagLayout()); //contains 3 buttons::create, maintain, test

        left_RM.setBackground(mm_color);
        left_RM.setPreferredSize(new Dimension(250, 1800));
        center_RM.setBackground(mm_color);
        center_RM.setPreferredSize(new Dimension(500, 1800));
        right_RM.setBackground(mm_color);
        right_RM.setPreferredSize(new Dimension(250, 1800));


        //getting the image element

        String both_path_RM = "C:\\school-prog-files\\elements\\bothVMS.png";
        ImageIcon both_Image_RM = new ImageIcon(both_path_RM);
        Image ogboth_Image_RM = both_Image_RM.getImage();
        Image both_Resized_RM = ogboth_Image_RM.getScaledInstance(250, 350, Image.SCALE_SMOOTH);
        ImageIcon resizedboth_RM = new ImageIcon(both_Resized_RM);
        JLabel both_label_RM = new JLabel(resizedboth_RM);

        GridBagConstraints gbc_RM = new GridBagConstraints();
        gbc_RM.gridx = 0;
        gbc_RM.anchor = GridBagConstraints.CENTER;
        gbc_RM.insets = new Insets(-1300, 0, 0, 0);
        gbc_RM.gridy = 0;
        left_RM.add(both_label_RM, gbc_RM);

        gbc_RM.insets = new Insets(-600, 0, 0, 0);
        gbc_RM.gridy = 1;
        JButton back_RM = new JButton("Back");
        back_RM.setBackground(buttons_color);
        back_RM.setPreferredSize(new Dimension(160, 30));
        back_RM.setFont(buttonFont);
        left_RM.add(back_RM, gbc_RM);

        center_RM.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel center1_RM = new JPanel();
        center1_RM.setBorder(null);
        center1_RM.setPreferredSize(new Dimension(200, 550));
        center1_RM.setBackground(mm_color);
        JPanel center2_RM = new JPanel();
        center_RM.setLayout(new FlowLayout());
        center1_RM.setLayout(new GridLayout(4, 2, 5, 15));
        center2_RM.setLayout(new GridLayout(2, 1, 10, 50));
        center2_RM.setPreferredSize(new Dimension(250, 600));


        //for center 1
        ImageIcon carrots_RM = new ImageIcon("C:\\school-prog-files\\elements\\carrots1.png");
        JButton slot1_RM = new JButton(carrots_RM);
        slot1_RM.setPreferredSize(new Dimension(100, 100));
        slot1_RM.setText(null);
        slot1_RM.setBorderPainted(false);
        slot1_RM.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot1_RM.setBackground(mm_color);
        center1_RM.add(slot1_RM);

        ImageIcon mushrooms_RM = new ImageIcon("C:\\school-prog-files\\elements\\mushroom.png");
        JButton slot2_RM = new JButton(mushrooms_RM);
        slot2_RM.setPreferredSize(new Dimension(100, 50));
        slot2_RM.setText(null);
        slot2_RM.setBorderPainted(false);
        slot2_RM.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot2_RM.setBackground(mm_color);
        center1_RM.add(slot2_RM);


        ImageIcon broccoli_RM = new ImageIcon("C:\\school-prog-files\\elements\\broccoli.png");
        JButton slot3_RM = new JButton(broccoli_RM);
        slot3_RM.setPreferredSize(new Dimension(100, 100));
        slot3_RM.setText(null);
        slot3_RM.setBorderPainted(false);
        slot3_RM.setBorder(null);
        slot3_RM.setBackground(mm_color);
        center1_RM.add(slot3_RM);

        ImageIcon bitterGourd_RM = new ImageIcon("C:\\school-prog-files\\elements\\bitterGourd.png");
        JButton slot4_RM = new JButton(bitterGourd_RM);
        slot4_RM.setPreferredSize(new Dimension(100, 100));
        slot4_RM.setText(null);
        slot4_RM.setBorderPainted(false);
        slot4_RM.setBorder(null);
        slot4_RM.setBackground(mm_color);
        center1_RM.add(slot4_RM);

        ImageIcon anchovy_RM = new ImageIcon("C:\\school-prog-files\\elements\\anchovy.png");
        JButton slot5_RM = new JButton(anchovy_RM);
        slot5_RM.setPreferredSize(new Dimension(100, 100));
        slot5_RM.setText(null);
        slot5_RM.setBorderPainted(false);
        slot5_RM.setBorder(null);
        slot5_RM.setBackground(mm_color);
        center1_RM.add(slot5_RM);


        ImageIcon rice_RM = new ImageIcon("C:\\school-prog-files\\elements\\rice.png");
        JButton slot6_RM = new JButton(rice_RM);
        slot6_RM.setPreferredSize(new Dimension(100, 100));
        slot6_RM.setText(null);
        slot6_RM.setBorderPainted(false);
        slot6_RM.setBackground(mm_color);
        slot6_RM.setBorder(null);
        center1_RM.add(slot6_RM);

        ImageIcon squash_RM = new ImageIcon("C:\\school-prog-files\\elements\\squash.png");
        JButton slot7_RM = new JButton(squash_RM);
        slot7_RM.setPreferredSize(new Dimension(100, 100));
        slot7_RM.setText(null);
        slot7_RM.setBorderPainted(false);
        slot7_RM.setBorder(null);
        slot7_RM.setBackground(mm_color);
        center1_RM.add(slot7_RM);

        ImageIcon tomato_RM = new ImageIcon("C:\\school-prog-files\\elements\\tomato.png");
        JButton slot8_RM = new JButton(tomato_RM);
        slot8_RM.setPreferredSize(new Dimension(100, 100));
        slot8_RM.setText(null);
        slot8_RM.setBorderPainted(false);
        slot8_RM.setBorder(null);
        slot8_RM.setBackground(mm_color);
        center1_RM.add(slot8_RM);


        //for center 2
        JTextArea display_RM = new JTextArea();
        JTextArea total_due_RM = new JTextArea();
        display_RM.setPreferredSize(new Dimension(250, 500));
        display_RM.setWrapStyleWord(true);
        display_RM.setLineWrap(true);
        total_due_RM.setPreferredSize(new Dimension(250, 50));
        display_RM.setEditable(false);
        total_due_RM.setEditable(false);

        center2_RM.add(display_RM);
        center2_RM.add(total_due_RM);

        center_RM.add(center1_RM);
        center_RM.add(center2_RM);

        right_RM.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));


        JPanel top_RM = new JPanel();
        top_RM.setPreferredSize(new Dimension(200, 50));
        JPanel mid_RM = new JPanel();
        mid_RM.setLayout(new GridLayout(2, 3));
        JPanel bottom_RM = new JPanel();

        JLabel PayMe_RM = new JLabel("SPECIAL");
        PayMe_RM.setFont(buttonFont);
        top_RM.add(PayMe_RM);


        bottom_RM.setLayout(new GridLayout(5, 1, 0, 20));
        bottom_RM.setPreferredSize(new Dimension(250, 500));
        JButton restock_RM = new JButton("RESTOCK");
        restock_RM.setFont(buttonFont);
        restock_RM.setBackground(buttons_color);
        bottom_RM.add(restock_RM);

        JButton modify_RM = new JButton("MODIFY PRICE");
        modify_RM.setFont(buttonFont);
        modify_RM.setBackground(buttons_color);
        bottom_RM.add(modify_RM);

        JButton collect_RM = new JButton("COLLECT MONEY");
        collect_RM.setFont(buttonFont);
        collect_RM.setBackground(buttons_color);
        bottom_RM.add(collect_RM);

        JButton replenish_RM = new JButton("REPLENISH MONEY");
        replenish_RM.setFont(buttonFont);
        replenish_RM.setBackground(buttons_color);
        bottom_RM.add(replenish_RM);

        JTextField input_RM = new JTextField("INPUT");
        input_RM.setFont(buttonFont);
        input_RM.setBackground(buttons_color);
        bottom_RM.add(input_RM);


        right_RM.add(top_RM);
        right_RM.add(mid_RM);
        right_RM.add(bottom_RM);


        //-----------------------------------------------------------------
        //===================MAINTAIN VIEW SVM===============================


        JFrame svm_main = new JFrame("SVM Maintenance");
        svm_main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        svm_main.setSize(1920, 1800); // Set a reasonable initial size
        /*
         * Color mm_color = new Color(30,30,30);
         * Color buttons_color = new Color(250,250,250);
         * Font buttonFont = new Font("EFour Digital Pro", Font.PLAIN, 20);
         * */

        svm_main.getContentPane().setBackground(mm_color);
        svm_main.setLayout(new FlowLayout());

        //"C:\\school-prog-files\\elements

        JPanel left_SM = new JPanel(new GridBagLayout()); //contains rvm drawing and button
        JPanel center_SM = new JPanel(/*new GridBagLayout()*/); //contains svm drawing and button
        JPanel right_SM = new JPanel(new GridBagLayout()); //contains 3 buttons::create, maintain, test

        left_SM.setBackground(mm_color);
        left_SM.setPreferredSize(new Dimension(250, 1800));
        center_SM.setBackground(mm_color);
        center_SM.setPreferredSize(new Dimension(500, 1800));
        right_SM.setBackground(mm_color);
        right_SM.setPreferredSize(new Dimension(250, 1800));


        //getting the image element

        String both_path_SM = "C:\\school-prog-files\\elements\\bothVMS.png";
        ImageIcon both_Image_SM = new ImageIcon(both_path_SM);
        Image ogboth_Image_SM = both_Image_SM.getImage();
        Image both_Resized_SM = ogboth_Image_SM.getScaledInstance(250, 350, Image.SCALE_SMOOTH);
        ImageIcon resizedboth_SM = new ImageIcon(both_Resized_SM);
        JLabel both_label_SM = new JLabel(resizedboth_SM);

        GridBagConstraints gbc_SM = new GridBagConstraints();
        gbc_SM.gridx = 0;
        gbc_SM.anchor = GridBagConstraints.CENTER;
        gbc_SM.insets = new Insets(-1300, 0, 0, 0);
        gbc_SM.gridy = 0;
        left_SM.add(both_label_SM, gbc_SM);

        gbc_SM.insets = new Insets(-600, 0, 0, 0);
        gbc_SM.gridy = 1;
        JButton back_SM = new JButton("Back");
        back_SM.setBackground(buttons_color);
        back_SM.setPreferredSize(new Dimension(160, 30));
        back_SM.setFont(buttonFont);
        left_SM.add(back_SM, gbc_SM);

        center_SM.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel center1_SM = new JPanel();
        center1_SM.setBorder(null);
        center1_SM.setPreferredSize(new Dimension(200, 550));
        center1_SM.setBackground(mm_color);
        JPanel center2_SM = new JPanel();
        center_SM.setLayout(new FlowLayout());
        center1_SM.setLayout(new GridLayout(4, 2, 5, 15));
        center2_SM.setLayout(new GridLayout(2, 1, 10, 50));
        center2_SM.setPreferredSize(new Dimension(250, 600));


        //for center 1
        ImageIcon carrots_SM = new ImageIcon("C:\\school-prog-files\\elements\\carrots1.png");
        JButton slot1_SM = new JButton(carrots_SM);
        slot1_SM.setPreferredSize(new Dimension(100, 100));
        slot1_SM.setText(null);
        slot1_SM.setBorderPainted(false);
        slot1_SM.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot1_SM.setBackground(mm_color);
        center1_SM.add(slot1_SM);

        ImageIcon mushrooms_SM = new ImageIcon("C:\\school-prog-files\\elements\\mushroom.png");
        JButton slot2_SM = new JButton(mushrooms_SM);
        slot2_SM.setPreferredSize(new Dimension(100, 50));
        slot2_SM.setText(null);
        slot2_SM.setBorderPainted(false);
        slot2_SM.setBorder(null);
        //slot1.setContentAreaFilled(false);
        slot2_SM.setBackground(mm_color);
        center1_SM.add(slot2_SM);


        ImageIcon broccoli_SM = new ImageIcon("C:\\school-prog-files\\elements\\broccoli.png");
        JButton slot3_SM = new JButton(broccoli_SM);
        slot3_SM.setPreferredSize(new Dimension(100, 100));
        slot3_SM.setText(null);
        slot3_SM.setBorderPainted(false);
        slot3_SM.setBorder(null);
        slot3_SM.setBackground(mm_color);
        center1_SM.add(slot3_SM);

        ImageIcon bitterGourd_SM = new ImageIcon("C:\\school-prog-files\\elements\\bitterGourd.png");
        JButton slot4_SM = new JButton(bitterGourd_SM);
        slot4_SM.setPreferredSize(new Dimension(100, 100));
        slot4_SM.setText(null);
        slot4_SM.setBorderPainted(false);
        slot4_SM.setBorder(null);
        slot4_SM.setBackground(mm_color);
        center1_SM.add(slot4_SM);

        ImageIcon anchovy_SM = new ImageIcon("C:\\school-prog-files\\elements\\anchovy.png");
        JButton slot5_SM = new JButton(anchovy_SM);
        slot5_SM.setPreferredSize(new Dimension(100, 100));
        slot5_SM.setText(null);
        slot5_SM.setBorderPainted(false);
        slot5_SM.setBorder(null);
        slot5_SM.setBackground(mm_color);
        center1_SM.add(slot5_SM);


        ImageIcon rice_SM = new ImageIcon("C:\\school-prog-files\\elements\\rice.png");
        JButton slot6_SM = new JButton(rice_SM);
        slot6_SM.setPreferredSize(new Dimension(100, 100));
        slot6_SM.setText(null);
        slot6_SM.setBorderPainted(false);
        slot6_SM.setBackground(mm_color);
        slot6_SM.setBorder(null);
        center1_SM.add(slot6_SM);

        ImageIcon squash_SM = new ImageIcon("C:\\school-prog-files\\elements\\squash.png");
        JButton slot7_SM = new JButton(squash_SM);
        slot7_SM.setPreferredSize(new Dimension(100, 100));
        slot7_SM.setText(null);
        slot7_SM.setBorderPainted(false);
        slot7_SM.setBorder(null);
        slot7_SM.setBackground(mm_color);
        center1_SM.add(slot7_SM);

        ImageIcon tomato_SM = new ImageIcon("C:\\school-prog-files\\elements\\tomato.png");
        JButton slot8_SM = new JButton(tomato_SM);
        slot8_SM.setPreferredSize(new Dimension(100, 100));
        slot8_SM.setText(null);
        slot8_SM.setBorderPainted(false);
        slot8_SM.setBorder(null);
        slot8_SM.setBackground(mm_color);
        center1_SM.add(slot8_SM);


        //for center 2
        JTextArea display_SM = new JTextArea();
        JTextArea total_due_SM = new JTextArea();
        display_SM.setPreferredSize(new Dimension(250, 500));
        display_SM.setWrapStyleWord(true);
        display_SM.setLineWrap(true);
        total_due_SM.setPreferredSize(new Dimension(250, 50));
        display_SM.setEditable(false);
        total_due_SM.setEditable(false);

        center2_SM.add(display_SM);
        center2_SM.add(total_due_SM);

        center_SM.add(center1_SM);
        center_SM.add(center2_SM);

        right_SM.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));


        JPanel top_SM = new JPanel();
        top_SM.setPreferredSize(new Dimension(200, 50));
        JPanel mid_SM = new JPanel();
        mid_SM.setLayout(new GridLayout(2, 3));
        JPanel bottom_SM = new JPanel();

        JLabel PayMe_SM = new JLabel("SPECIAL");
        PayMe_SM.setFont(buttonFont);
        top_SM.add(PayMe_SM);


        bottom_SM.setLayout(new GridLayout(5, 1, 0, 20));
        bottom_SM.setPreferredSize(new Dimension(250, 500));
        JButton restock_SM = new JButton("RESTOCK");
        restock_SM.setFont(buttonFont);
        restock_SM.setBackground(buttons_color);
        bottom_SM.add(restock_SM);

        JButton modify_SM = new JButton("MODIFY");
        modify_SM.setFont(buttonFont);
        modify_SM.setBackground(buttons_color);
        bottom_SM.add(modify_SM);

        JButton collect_SM = new JButton("COLLECT MONEY");
        collect_SM.setFont(buttonFont);
        collect_SM.setBackground(buttons_color);
        bottom_SM.add(collect_SM);

        JButton replenish_SM = new JButton("REPLENISH");
        replenish_SM.setFont(buttonFont);
        replenish_SM.setBackground(buttons_color);
        bottom_SM.add(replenish_SM);

        JTextField input_SM = new JTextField("INPUT: ");
        input_SM.setFont(buttonFont);
        input_SM.setBackground(buttons_color);
        bottom_SM.add(input_SM);


        right_SM.add(top_SM);
        right_SM.add(mid_SM);
        right_SM.add(bottom_SM);


        //-----------------------------------------------------------------
        //-----------------------------------------------------------------
        //Letz make ze buhtons usefool

        //==========================menu buttons============================

        maintain.addActionListener(e -> {
            mainMenu.setVisible(false);
            if (vmType == 1) {
                svm_main.setVisible(true);
            } else
                rvm_main.setVisible(true);
        });

        svmButton.addActionListener(e -> {
            // Actions to perform when the button is clicked
            vmType = 1;
            JOptionPane.showMessageDialog(mainMenu, "You've chosen SVM!", "Notification", JOptionPane.INFORMATION_MESSAGE);
        });

        rvmButton.addActionListener(e -> {
            // Actions to perform when the button is clicked
            vmType = 0;
            JOptionPane.showMessageDialog(mainMenu, "You've chosen RVM!", "Notification", JOptionPane.INFORMATION_MESSAGE);
        });

        create.addActionListener(e -> {

            if (vmType == 0) {
                JOptionPane.showMessageDialog(mainMenu, "You've created a regular vending machine!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                vendingMachine = runCreate();
            } else {
                JOptionPane.showMessageDialog(mainMenu, "You've created a special vending machine!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                List<Item> itemBought = null;
                specialVendingMachine = runSpecial(itemBought);
            }


        });

        test.addActionListener(e -> {

            mainMenu.setVisible(false);
            basic_buy.setVisible(true);


        });

        available_s.addActionListener(e -> {

            specialVendingMachine.displayAvailable(vendingMachine.getUserPurchased(), display_s);
        });


        //=========================BASIC-BUY BUTTONS=======================

        back_bb.addActionListener(e -> {

            basic_buy.setVisible(false);
            mainMenu.setVisible(true);

        });

        //itemType = 1
        slot1.addActionListener(e -> {
            if (itemType_reg == 1) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Carrots");
            } else {
                vendingMachine.displayItem("Carrot", display_bb);
                display_bb.append("\nYou've chosen CARROT!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 1;
            }
        });

        slot2.addActionListener(e -> {

            if (itemType_reg == 2) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Mushrooms");
            } else {
                vendingMachine.displayItem("Mushroom", display_bb);
                display_bb.append("\nYou've chosen Mushrooms!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 2;
            }

        });

        slot3.addActionListener(e -> {

            if (itemType_reg == 3) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Broccoli");
            } else {
                vendingMachine.displayItem("Broccoli", display_bb);
                display_bb.append("\nYou've chosen Broccoli!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 3;
            }

        });

        slot4.addActionListener(e -> {

            if (itemType_reg == 4) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Ampalaya");
            } else {
                vendingMachine.displayItem("Ampalaya", display_bb);
                display_bb.append("\nYou've chosen Ampalaya!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 4;
            }

        });

        slot5.addActionListener(e -> {

            if (itemType_reg == 5) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Anchovy");
            } else {
                vendingMachine.displayItem("Anchovy", display_bb);
                display_bb.append("\nYou've chosen Anchovy!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 5;
            }

        });

        slot6.addActionListener(e -> {

            if (itemType_reg == 6) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Rice");
            } else {
                vendingMachine.displayItem("Rice", display_bb);
                display_bb.append("\nYou've chosen Rice!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 6;
            }

        });

        slot7.addActionListener(e -> {
            if (itemType_reg == 7) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Squash");
            } else {
                vendingMachine.displayItem("Squash", display_bb);
                display_bb.append("\nYou've chosen Squash!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 7;
            }

        });

        slot8.addActionListener(e -> {
            if (itemType_reg == 8) {
                quantity_items = quantity_items + 1;
                display_bb.setText("You're currently ordering: " +
                        quantity_items + " Tomato");
            } else {
                vendingMachine.displayItem("Tomato", display_bb);
                display_bb.append("\nYou've chosen Tomato!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_reg = 8;
            }
        });

        bente.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = Main.wallet + 20;
                display_bb.setText("You added 20!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }
        });

        pipty.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = Main.wallet + 50;
                display_bb.setText("You added 50 to the digital wallet!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }
        });

        wanhandred.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = Main.wallet + 100;
                display_bb.setText("You added 100 to the digital wallet!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }

        });

        fortune500.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = Main.wallet + 500;
                display_bb.setText("You added 500 to the digital wallet!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }
        });

        oneGrand.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = Main.wallet + 1000;
                display_bb.setText("You added 1000 to the digital wallet!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }
        });

        clearMoolah.addActionListener(e -> {
            if (vendingMachine != null) {
                Main.wallet = 0;
                display_bb.setText("You cleared the digital wallet!\n" +
                        "Current digital wallet:" + Main.wallet + "\n");
            }
        });

        displayInventory.addActionListener(e -> {
            vendingMachine.displayInventory(display_bb);
        });


        displayInventory_s.addActionListener(e -> {
            specialVendingMachine.displayInventory(display_s);
        });

        pastGastos.addActionListener(e -> {
            vendingMachine.printTransactions(display_bb);

        });

        pastGastos_s.addActionListener(e -> {
            specialVendingMachine.printTransactions(display_s);

        });


        specialMenu.addActionListener(e -> {

            if (vmType == 0) {
                JOptionPane.showMessageDialog(basic_buy, "Special locked. Use an SVM to access", "Notification", JOptionPane.INFORMATION_MESSAGE);
            } else {
                basic_buy.setVisible(false);
                special_buy.setVisible(true);
            }

        });

        checkout.addActionListener(e -> {
            if (vmType == 0) {
                String itemName;
                switch (itemType_reg) {
                    case 1:
                        itemName = "Carrot";
                        break;
                    case 2:
                        itemName = "Mushroom";
                        break;
                    case 3:
                        itemName = "Broccoli";
                        break;
                    case 4:
                        itemName = "Ampalaya";
                        break;
                    case 5:
                        itemName = "Anchovy";
                        break;
                    case 6:
                        itemName = "Rice";
                        break;
                    case 7:
                        itemName = "Squash";
                        break;
                    default:
                        itemName = "Tomato";
                        break;
                }

                vendingMachine.buyItem(itemName, Main.wallet, quantity_items, display_bb);
            }

        });

        checkout_s.addActionListener(e -> {
            if (vmType == 1) {
                String specialItemCode;
                switch (itemType_spc) {
                    case 1:
                        specialItemCode = "CMB";
                        break;
                    case 2:
                        specialItemCode = "ARB";
                        break;
                    case 3:
                        specialItemCode = "SRB";
                        break;
                    case 4:
                        specialItemCode = "SSR";
                        break;
                    case 5:
                        specialItemCode = "TRS";
                        break;
                    case 6:
                        specialItemCode = "SAFR";
                        break;
                    case 7:
                        specialItemCode = "MRS";
                        break;
                    default:
                        specialItemCode = "BAT";
                        break;
                }
                specialVendingMachine.buySpecialItem(specialItemCode, Main.wallet, quantity_items, display_s);
            }
        });

        //===================        SVM BUY BUTTONS     =======================

        slot11.addActionListener(e -> {
            if (itemType_spc == 1) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Stir-fried Rice with CMB");
            } else {
                specialVendingMachine.displayItem("CMB", display_s);
                display_s.append("\nYou've chosen Stir-fried Rice with CMB!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 1;
            }
        });

        slot22.addActionListener(e -> {
            if (itemType_spc == 2) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Anchovy Rice Bowl with Squash & Tomato");
            } else {
                specialVendingMachine.displayItem("ARB", display_s);
                display_s.append("\nYou've chosen ARB!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 2;
            }
        });

        slot33.addActionListener(e -> {
            if (itemType_spc == 3) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Steamed Rice with Broccoli & Bitter Gourd");
            } else {
                specialVendingMachine.displayItem("SRB", display_s);
                display_s.append("\nYou've chosen SRB!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 3;
            }
        });

        slot44.addActionListener(e -> {
            if (itemType_spc == 4) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Special Squash & Rice Cup");
            } else {
                specialVendingMachine.displayItem("SSR", display_s);
                display_s.append("\nYou've chosen SSR!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 4;
            }
        });

        slot55.addActionListener(e -> {
            if (itemType_spc == 5) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Tomato & Rice Salad");
            } else {
                specialVendingMachine.displayItem("TRS", display_s);
                display_s.append("\nYou've chosen TRS!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 5;
            }
        });

        slot66.addActionListener(e -> {
            if (itemType_spc == 6) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Special Anchovy Fried Rice");
            } else {
                specialVendingMachine.displayItem("SAFR", display_s);
                display_s.append("\nYou've chosen SAFR!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 6;
            }
        });

        slot77.addActionListener(e -> {
            if (itemType_spc == 7) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " Mushroom and Rice Soup");
            } else {
                specialVendingMachine.displayItem("MRS", display_s);
                display_s.append("\nYou've chosen MRS!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 7;
            }
        });

        slot88.addActionListener(e -> {
            if (itemType_spc == 8) {
                quantity_items = quantity_items + 1;
                display_s.setText("You're currently ordering: " +
                        quantity_items + " BAT Fried Rice");
            } else {
                specialVendingMachine.displayItem("BAT", display_s);
                display_s.append("\nYou've chosen BAT!\n" +
                        "Click for the quantity you want");
                quantity_items = 0;
                itemType_spc = 8;
            }
        });


        //=========================BASIC-BUY BUTTONS-SVM=======================

        back_s.addActionListener(e -> {
            special_buy.setVisible(false);
            basic_buy.setVisible(true);
        });


        //===================Vending Machine Regular========================

        back_RM.addActionListener(e -> {
            rvm_main.setVisible(false);
            mainMenu.setVisible(true);
        });

        slot1_RM.addActionListener(e -> {
            itemType_reg = 1;
            display_RM.append("You've chosen slot 1\n");
        });

        slot2_RM.addActionListener(e -> {
            itemType_reg = 2;
            display_RM.append("You've chosen slot 2\n");
        });

        slot3_RM.addActionListener(e -> {
            itemType_reg = 3;
            display_RM.append("You've chosen slot 3\n");
        });

        slot4_RM.addActionListener(e -> {
            itemType_reg = 4;
            display_RM.append("You've chosen slot 4\n");
        });

        slot5_RM.addActionListener(e -> {
            itemType_reg = 5;
            display_RM.append("You've chosen slot 5\n");
        });

        slot6_RM.addActionListener(e -> {
            itemType_reg = 6;
            display_RM.append("You've chosen slot 6\n");
        });

        slot7_RM.addActionListener(e -> {
            itemType_reg = 7;
            display_RM.append("You've chosen slot 7\n");
        });

        slot8_RM.addActionListener(e -> {
            itemType_reg = 8;
            display_RM.append("You've chosen slot 8\n");
        });

        restock_RM.addActionListener(e -> {
            if (itemType_reg > 0) {
                String itemName = "Item" + itemType_reg;
                display_RM.append("Restocking: Slot " + itemType_reg + "\n");
                regular.restockItems(itemName, display_RM);
            } else {
                display_RM.append("Please choose a slot first.\n");
            }
        });

        restock_RM.addActionListener(e -> {
            if (itemType_reg > 0) {
                String itemName = "Item" + itemType_reg;
                display_RM.append("Restocking: Slot " + itemType_reg + "\n");
                regular.restockItems(itemName, display_RM);
            } else {
                display_RM.append("Please choose a slot first.\n");
            }
        });

        restock_RM.addActionListener(e -> {
            if (itemType_reg > 0) {
                String itemName = "Item" + itemType_reg;
                display_RM.append("Restocking: Slot " + itemType_reg + "\n");
                regular.restockItems(itemName, display_RM);
            } else {
                display_RM.append("Please choose a slot first.\n");
            }
        });

        modify_RM.addActionListener(e -> {
            if (itemType_reg > 0) {
                Slot slot = vendingMachine.getSlots()[itemType_reg - 1];
                Item selectedItem = slot.getItems();

                if (selectedItem != null) {
                    try {
                        float newPrice = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));
                        regular.setPrice(selectedItem, newPrice, display_RM);
                        selectedItem.setPrice(newPrice);
                        display_RM.append("Price of " + selectedItem.getItemName() + " has been modified to: " + newPrice + "\n");
                    } catch (NumberFormatException ex) {
                        display_RM.append("Invalid input. Please enter a valid float.\n");
                    }
                } else {
                    display_RM.append("Slot " + itemType_reg + " is empty. Please choose a different slot.\n");
                }
            } else {
                display_RM.append("Please choose a slot first.\n");
            }
        });

        collect_RM.addActionListener(e -> {
            try {
                float collect = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));
                display_RM.append("Collecting money... " + collect + "\n");
                regular.collectMoney(collect, display_RM);
            } catch (NumberFormatException ex) {
                display_RM.append("Invalid input. Please enter a valid float.\n");
            }
        });

        replenish_RM.addActionListener(e -> {
            try {
                float replenishAmount = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));
                if (replenishAmount > 0) {
                    display_RM.append("Replenishing money " + replenishAmount + "\n");
                    regular.replenishMoney(replenishAmount, display_RM);
                } else {
                    display_RM.append("Invalid input. Please enter a valid positive float for replenishing money.\n");
                }
            } catch (NumberFormatException ex) {
                display_RM.append("Invalid input. Please enter a valid float.\n");
            }
        });

        //===================Vending Machine Special========================

        back_SM.addActionListener(e -> {
            svm_main.setVisible(false);
            mainMenu.setVisible(true);
        });

        slot1_SM.addActionListener(e -> {
            itemType_spc = 1;
            display_SM.append("You've chosen slot 1\n");
        });

        slot2_SM.addActionListener(e -> {
            itemType_spc = 2;
            display_SM.append("You've chosen slot 2\n");
        });

        slot3_SM.addActionListener(e -> {
            itemType_spc = 3;
            display_SM.append("You've chosen slot 3\n");
        });

        slot4_SM.addActionListener(e -> {
            itemType_spc = 4;
            display_SM.append("You've chosen slot 4\n");
        });

        slot5_SM.addActionListener(e -> {
            itemType_spc = 5;
            display_SM.append("You've chosen slot 5\n");
        });

        slot6_SM.addActionListener(e -> {
            itemType_spc = 6;
            display_SM.append("You've chosen slot 6\n");
        });

        slot7_SM.addActionListener(e -> {
            itemType_spc = 7;
            display_SM.append("You've chosen slot 7\n");
        });

        slot8_SM.addActionListener(e -> {
            itemType_spc = 8;
            display_SM.append("You've chosen slot 8\n");
        });


        restock_SM.addActionListener(e -> {
            if (itemType_spc > 0) {
                String itemName = "Item" + itemType_spc;
                display_SM.append("Restocking: Slot " + itemType_spc + "\n");
                special.restockItems(itemName, display_SM);
            } else {
                display_SM.append("Please choose a slot first.\n");
            }
        });

        modify_SM.addActionListener(e -> {
            if (itemType_spc > 0) {
                Slot slot = specialVendingMachine.getSlots()[itemType_spc - 1];
                SpecialItem selectedItem = slot.getSpecialItem();

                if (selectedItem != null) {
                    try {
                        float newPrice = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));

                        if (newPrice > 0) {
                            special.setPrice(selectedItem, newPrice, display_SM);
                            selectedItem.setPrice(newPrice);
                            display_SM.append("Price of " + selectedItem.getName() + " has been modified to: " + newPrice + "\n");
                        } else {
                            display_SM.append("Invalid input. Please enter a valid positive float for the new price.\n");
                        }
                    } catch (NumberFormatException ex) {
                        display_SM.append("Invalid input. Please enter a valid float.\n");
                    }
                } else {
                    display_SM.append("Slot " + itemType_spc + " is empty. Please choose a different slot.\n");
                }
            } else {
                display_SM.append("Please choose a slot first.\n");
            }
        });

        collect_SM.addActionListener(e -> {
            try {
                float collect = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));
            display_SM.append("Collecting money..." + collect + "\n");
            special.collectMoney(Main.quantity_money, display_SM);
            } catch (NumberFormatException ex) {
                display_RM.append("Invalid input. Please enter a valid float.\n");
            }
        });

        replenish_SM.addActionListener(e -> {
            try {
                float replenishAmount = Float.parseFloat(JOptionPane.showInputDialog(null, "Enter your amount: "));
                if (replenishAmount > 0) {
                    display_SM.append("Replenishing money " + replenishAmount + "\n");
                    special.replenishMoney(replenishAmount, display_SM);
                } else {
                    display_SM.append("Invalid input. Please enter a valid positive float for replenishing money.\n");
                }
            } catch (NumberFormatException ex) {
                display_SM.append("Invalid input. Please enter a valid float.\n");
            }
        });


        //==================Adding Frame Components========================

        basic_buy.add(leftbb);
        basic_buy.add(centerbb);
        basic_buy.add(rightbb);

        special_buy.add(lefts);
        special_buy.add(centers);
        special_buy.add(rights);

        rvm_main.add(left_RM);
        rvm_main.add(center_RM);
        rvm_main.add(right_RM);


        svm_main.add(left_SM);
        svm_main.add(center_SM);
        svm_main.add(right_SM);


        mainMenu.add(left);
        mainMenu.add(center);
        mainMenu.add(right);
        mainMenu.setVisible(true);
    }

    private static RVM runCreate() {
        RVM vendingMachine = new RVM(8);
        String m1 = "Vending machine created with a capacity of 8 slots & 10 items per slot.";
        String m2 = "You can now ACCESS the MAINTENANCE & TEST MENU of this machine.";

        regular = new Maintenance(vendingMachine);

        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(null, m1, "Notification", JOptionPane.INFORMATION_MESSAGE);
            JOptionPane.showMessageDialog(null, m2, "Notification", JOptionPane.INFORMATION_MESSAGE);
        });

        Item carrot = new Item("Carrot", 41, 50);
        Item mushroom = new Item("Mushroom", 22, 150);
        Item broccoli = new Item("Broccoli", 34, 120);
        Item bitterGourd = new Item("Ampalaya", 17, 80);
        Item anchovy = new Item("Anchovy", 130, 40);
        Item rice = new Item("Rice", 371, 150);
        Item squash = new Item("Squash", 16, 40);
        Item tomato = new Item("Tomato", 18, 60);


        JTextArea display = new JTextArea();

        vendingMachine.setItem(carrot, 10, display);
        vendingMachine.setItem(mushroom, 10, display);
        vendingMachine.setItem(broccoli, 10, display);
        vendingMachine.setItem(bitterGourd, 10, display);
        vendingMachine.setItem(anchovy, 10, display);
        vendingMachine.setItem(rice, 10, display);
        vendingMachine.setItem(squash, 10, display);
        vendingMachine.setItem(tomato, 10, display);

        return vendingMachine;
    }

    private static SVM runSpecial(List<Item> itemBought) {
        if (specialVendingMachine == null || !specialVendingMachine.getUserPurchased().equals(itemBought)) {
            specialVendingMachine = new SVM(8);
            specialVendingMachine.setUserPurchased(vendingMachine.getUserPurchased());

            SpecialMaintenance special = new SpecialMaintenance(specialVendingMachine);

            String m1 = "Special vending machine created with a capacity of 8 slots & 10 items per slot.";
            String m2 = "You can now ACCESS the MAINTENANCE & TEST MENU of this machine.";

            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(null, m1, "Notification", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, m2, "Notification", JOptionPane.INFORMATION_MESSAGE);
            });

            Item carrot = new Item("Carrot", 41, 50);
            Item mushroom = new Item("Mushroom", 22, 150);
            Item broccoli = new Item("Broccoli", 34, 120);
            Item bitterGourd = new Item("Ampalaya", 17, 80);
            Item anchovy = new Item("Anchovy", 130, 40);
            Item rice = new Item("Rice", 371, 150);
            Item squash = new Item("Squash", 16, 40);
            Item tomato = new Item("Tomato", 18, 60);

            Item[] itemList = {carrot, mushroom, broccoli, bitterGourd, anchovy, rice, squash, tomato};


            // SpecialItem 1: Stir-fried Rice with CMB (CMB)
            Item[] cmbIngredients = {rice, carrot, mushroom};
            int[] cmbQuantities = {2, 1, 1};
            List<String> cmbCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Slicing carrots...",
                    "Slicing mushrooms...",
                    "Stir-frying all ingredients..."
            );
            SpecialItem CMB = new SpecialItem("Stir-fried Rice with CMB (CMB)", "CMB", 600, 150, itemList, cmbIngredients, cmbQuantities, cmbCookingSteps);

            // SpecialItem 2: Anchovy Rice Bowl with Squash & Tomato (ARB)
            Item[] arbIngredients = {rice, anchovy, squash, tomato};
            int[] arbQuantities = {2, 2, 1, 1};
            List<String> arbCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Cooking anchovies...",
                    "Dicing squash...",
                    "Dicing tomatoes...",
                    "Adding special sauce...",
                    "Mixing all ingredients..."
            );
            SpecialItem ARB = new SpecialItem("Anchovy Rice Bowl with Squash & Tomato (ARB)", "ARB", 500, 200, itemList, arbIngredients, arbQuantities, arbCookingSteps);
            ARB.addSpecialIngredient("Special Sauce");

            // SpecialItem 3: Steamed Rice with Broccoli & Bitter Gourd (SRB)
            Item[] srbIngredients = {rice, broccoli, bitterGourd};
            int[] srbQuantities = {2, 1, 1};
            List<String> srbCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Steaming broccoli...",
                    "Slicing bitter gourd...",
                    "Mixing all ingredients..."
            );
            SpecialItem SRB = new SpecialItem("Steamed Rice with Broccoli & Bitter Gourd (SRB)", "SRB", 400, 150, itemList, srbIngredients, srbQuantities, srbCookingSteps);

            // SpecialItem 4: Special Squash & Rice Cup (SSR)
            Item[] ssrIngredients = {rice, squash, tomato};
            int[] ssrQuantities = {1, 2, 1};
            List<String> ssrCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Dicing squash...",
                    "Dicing tomatoes...",
                    "Adding secret herbs and spices...",
                    "Mixing all ingredients..."
            );
            SpecialItem SSR = new SpecialItem("Special Squash & Rice Cup (SSR)", "SSR", 400, 150, itemList, ssrIngredients, ssrQuantities, ssrCookingSteps);
            SSR.addSpecialIngredient("Secret Herbs & Spices");

            // SpecialItem 5: Tomato & Rice Salad (TRS)
            Item[] trsIngredients = {rice, tomato, bitterGourd};
            int[] trsQuantities = {1, 1, 2};
            List<String> trsCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Dicing tomatoes...",
                    "Slicing bitter gourd...",
                    "Cooking anchovies...",
                    "Mixing all ingredients..."
            );
            SpecialItem TRS = new SpecialItem("Tomato & Rice Salad (TRS)", "TRS", 400, 150, itemList, trsIngredients, trsQuantities, trsCookingSteps);

            // SpecialItem 6: Special Anchovy Fried Rice (SAFR)
            Item[] safrIngredients = {rice, anchovy};
            int[] safrQuantities = {2, 2};
            List<String> safrCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Cooking anchovies...",
                    "Adding secret herbs and spices...",
                    "Mixing all ingredients..."
            );
            SpecialItem SAFR = new SpecialItem("Special Anchovy Fried Rice (SAFR)", "SAFR", 500, 200, itemList, safrIngredients, safrQuantities, safrCookingSteps);
            SAFR.addSpecialIngredient("Secret Herbs & Spices");

            // SpecialItem 7: Mushroom and Rice Soup (MRS)
            Item[] mrsIngredients = {rice, mushroom};
            int[] mrsQuantities = {2, 1};
            List<String> mrsCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Slicing mushrooms...",
                    "Adding vegetable broth...",
                    "Adding secret herbs and spices...",
                    "Mixing all ingredients..."
            );
            SpecialItem MRS = new SpecialItem("Mushroom and Rice Soup (MRS)", "MRS", 300, 150, itemList, mrsIngredients, mrsQuantities, mrsCookingSteps);
            MRS.addSpecialIngredient("Vegetable Broth");
            MRS.addSpecialIngredient("Secret Herbs & Spices");

            // SpecialItem 8: BAT Fried Rice (BAT)
            Item[] batIngredients = {rice, anchovy, tomato, broccoli};
            int[] batQuantities = {2, 1, 1, 1};
            List<String> batCookingSteps = Arrays.asList(
                    "Cooking rice...",
                    "Adding a cup of anchovies...",
                    "Adding a cup of tomatoes...",
                    "Adding a cup of broccoli...",
                    "Mixing all ingredients..."
            );
            SpecialItem BAT = new SpecialItem("BAT Fried Rice (BAT)", "BAT", 500, 200, itemList, batIngredients, batQuantities, batCookingSteps);

            JTextArea display = new JTextArea();
            specialVendingMachine.setSpecialItem(CMB, 10, display);
            specialVendingMachine.setSpecialItem(ARB, 10, display);
            specialVendingMachine.setSpecialItem(SRB, 10, display);
            specialVendingMachine.setSpecialItem(SSR, 10, display);
            specialVendingMachine.setSpecialItem(TRS, 10, display);
            specialVendingMachine.setSpecialItem(SAFR, 10, display);
            specialVendingMachine.setSpecialItem(MRS, 10, display);
            specialVendingMachine.setSpecialItem(BAT, 10, display);

        } else {
            JOptionPane.showMessageDialog(null, "Special vending machine already created for your purchased items.", "Notification", JOptionPane.INFORMATION_MESSAGE);
        }

        return specialVendingMachine;
    }




}