import javax.swing.*;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;

public class SVM {
    private Slot[] slots;
    private int capacity;
    private int totalSpecialItems;
    private float money;
    private float totalSales;
    private ArrayList<Transaction> transactions = new ArrayList<>();
    private List<Item> userPurchased;

    public SVM(int capacity) {
        this.capacity = capacity;
        slots = new Slot[capacity];
        this.money = 100000;
        for (int i = 0; i < capacity; i++) {
            slots[i] = new Slot(10);
        }
    }

    public void addSpecialItem(SpecialItem specialItem, int capacity, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        if (totalSpecialItems < capacity * 10) {
            for (int i = 0; i < slots.length; i++) {
                if (slots[i].getSpecialItem() == null) {
                    display.append("Adding item..." + "\n");
                    slots[i].setSpecialItem(specialItem);
                    slots[i].setQuantity(capacity, displayArea);
                    totalSpecialItems++;
                    display.append("Item added."+ "\n");
                    return;
                }
            }
        }

        displayArea.setText(display.toString());
    }

    public void setUserPurchased(List<Item> userPurchased) {
        this.userPurchased = userPurchased;
    }

    public void setSpecialItem(SpecialItem specialItem, int capacity, JTextArea displayArea) {
        if (totalSpecialItems < capacity * 10) {
            for (int i = 0; i < slots.length; i++) {
                if (slots[i].getSpecialItem() == null) {
                    slots[i].setSpecialItem(specialItem);
                    slots[i].setQuantity(capacity, displayArea);
                    totalSpecialItems++;
                    return;
                }
            }
        }
    }

    public void deleteSpecialItem(SpecialItem specialItem, JTextArea displayArea) {

        StringBuilder slot = new StringBuilder();

        for (int i = 0; i < slots.length; i++) {
            if (slots[i].getSpecialItem() != null && slots[i].getSpecialItem().equals(specialItem)) {
                slot.append("Deleting item..." + "\n");
                slots[i].setItems(null);
                slots[i].setSpecialItem(null);
                slots[i].setQuantity(0, displayArea);
                totalSpecialItems--;
                slot.append("Item deleted." + "\n");
                return;
            }
        }

        displayArea.setText(slot.toString());
    }

    public void displayItem(String itemName, JTextArea displayArea) {
        SpecialItem itemToDisplay = null;

        for (Slot slot : slots) {
            SpecialItem item = slot.getSpecialItem();
            if (item != null && item.getCode().equals(itemName)) {
                itemToDisplay = item;
                break;
            }
        }

        if (itemToDisplay == null) {
            displayArea.setText("Item not found: " + itemName);
        } else {
            StringBuilder itemz = new StringBuilder();
            itemz.append("ITEM\t:   " + itemToDisplay.getName() + "\n");
            itemz.append("PRICE\t:   " + itemToDisplay.getPrice() + "\n");
            itemz.append("CALORIES\t:   " + itemToDisplay.getCalorieCount() + "\n");

            // Get the quantity of the special item from the corresponding slot
            int quantity = getQuantityName(itemToDisplay);
            itemz.append("QUANTITY\t:   " + quantity + "\n");

            itemz.append("INGREDIENTS\t:   ");
            Map<Item, Integer> ingredients = itemToDisplay.getIngredients();
            int count = 0;
            for (Item ingredient : ingredients.keySet()) {
                int ingredientQuantity = ingredients.get(ingredient);
                itemz.append(ingredientQuantity + " " + ingredient.getItemName());
                if (++count < ingredients.size()) {
                    itemz.append(", ");
                }
            }
            itemz.append("\n");

            String specialIngredient = itemToDisplay.getSpecialIngredient();
            if (specialIngredient != null && !specialIngredient.isEmpty()) {
                itemz.append("OTHERS\t:   " + specialIngredient + "\n");
            }

            itemz.append("------------------------");

            displayArea.setText(itemz.toString());
        }
    }

    private int getQuantityName(SpecialItem item) {
        for (Slot slot : slots) {
            if (slot.getSpecialItem() == item) {
                return slot.getQuantity();
            }
        }
        return 0;
    }




    public void displayItemBought(JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        List<Item> itemBought = getUserPurchased();

        if (itemBought.isEmpty()) {
            display.append("You haven't bought any items yet." + "\n");
        } else {
            display.append("Items you have purchased:" + "\n");
            Map<String, Integer> itemCount = new HashMap<>();
            for (Item item : itemBought) {
                String itemName = item.getItemName();
                itemCount.put(itemName, itemCount.getOrDefault(itemName, 0) + 1);
            }

            for (Map.Entry<String, Integer> entry : itemCount.entrySet()) {
                String itemName = entry.getKey();
                int quantity = entry.getValue();

                display.append("NAME\t:   "  + itemName + "\n");
                display.append("CALORIES\t:   "  + itemBought.get(0).getCalorieCount() + "\n");
                display.append("PRICE\t:   "  + itemBought.get(0).getPrice() + "\n");
                display.append("PURCHASED\t:   "  + quantity + "\n");
                display.append("-------------------------");
            }
        }

        displayArea.setText(display.toString());

    }




    public void displayAvailable(List<Item> itemList, JTextArea displayArea) {
        StringBuilder display = new StringBuilder();

        display.append("Available Special Items: ");

        List<SpecialItem> availableSpecialItems = new ArrayList<>();

        for (Slot slot : slots) {
            if (slot != null) {
                SpecialItem specialItem = slot.getSpecialItem();
                if (specialItem != null && specialItem.containsIngredients(itemList)) {
                    availableSpecialItems.add(specialItem);
                }
            }
        }

        if (availableSpecialItems.isEmpty()) {
            display.append("No special recipes available for the items you bought." + "\n");
        } else {
            for (SpecialItem specialItem : availableSpecialItems) {
                display.append(specialItem.getName() + "\n");
            }
        }

        displayArea.setText(display.toString());

    }



    public void displayInventory(JTextArea displayArea) {
        StringBuilder inventory = new StringBuilder();
        inventory.append("Starting Inventory:\n");
        for (int i = 0; i < slots.length; i++) {
            SpecialItem specialItem = slots[i].getSpecialItem();
            if (specialItem != null) {
                inventory.append("Item: " + specialItem.getName() + ", Quantity: " + slots[i].getQuantity() + "\n");
            }
        }

        inventory.append("\n");

        inventory.append("Ending Inventory:\n");
        for (int i = 0; i < slots.length; i++) {
            SpecialItem specialItem = slots[i].getSpecialItem();
            if (specialItem != null) {
                inventory.append("Item: " + specialItem.getName() + ", Quantity: " + slots[i].getQuantity() + "\n");
            }

            displayArea.setText(inventory.toString());

        }
    }




    public void buySpecialItem(String code, float payment, int quantity, JTextArea displayArea) {
        StringBuilder display = new StringBuilder();

        SpecialItem foundItem = null;

        for (int i = 0; i < slots.length; i++) {
            SpecialItem slotSpecialItem = slots[i].getSpecialItem();
            if (slotSpecialItem != null && slotSpecialItem.getCode().equalsIgnoreCase(code)) {
                foundItem = slotSpecialItem;
                break;
            }
        }

        if (foundItem == null) {
            display.append("Item not found: " + code + "\n");
            displayArea.append(display.toString());
            return;
        }

        Map<Item, Integer> missingIngredients = getMissingIngredients(foundItem, quantity);
        if (!missingIngredients.isEmpty()) {
            display.append("\nCannot purchase " + foundItem.getName() + " due to missing ingredients:\n");
            for (Map.Entry<Item, Integer> entry : missingIngredients.entrySet()) {
                Item ingredient = entry.getKey();
                int missingQuantity = entry.getValue();
                display.append("Ingredient: " + ingredient.getItemName() + ", Missing Quantity: " + missingQuantity + "\n");
            }
            displayArea.append(display.toString());
            return;
        }

        float price = foundItem.getPrice();
        float totalCost = price * quantity;
        if (payment >= totalCost) {
            display.append("Item purchased: " + foundItem.getName() + "\n");
            display.append("Quantity purchased: " + quantity + "\n");
            display.append("Total cost: " + totalCost + "\n");
            float change = payment - totalCost;
            getChange(change, displayArea);
            totalSales += totalCost;
            for (int i = 0; i < slots.length; i++) {
                SpecialItem slotSpecialItem = slots[i].getSpecialItem();
                if (slotSpecialItem != null && slotSpecialItem.getCode().equalsIgnoreCase(code)) {
                    slots[i].decrementQuantity(quantity, displayArea);
                    break;
                }
            }
            Transaction transaction = new Transaction(createID(), foundItem, quantity, payment, change);
            transactions.add(transaction);
            foundItem.displayCookingSteps(displayArea);
        } else {
            display.append("Insufficient payment for item: " + foundItem.getName() + "\n");
            display.append("Please insert additional payment of: " + (totalCost - payment) + "\n");
            displayArea.append(display.toString());
        }
    }


    private Map<Item, Integer> getMissingIngredients(SpecialItem specialItem, int quantity) {
        Map<Item, Integer> missingIngredients = new HashMap<>();
        Map<Item, Integer> requiredIngredients = new HashMap<>(specialItem.getIngredients());

        for (Item ingredient : requiredIngredients.keySet()) {
            requiredIngredients.put(ingredient, requiredIngredients.get(ingredient) * quantity);
        }

        Map<Item, Integer> purchasedItemsMap = new HashMap<>();
        List<Item> userPurchasedItems = getUserPurchased();

        for (Item purchasedItem : userPurchasedItems) {
            purchasedItemsMap.put(purchasedItem, purchasedItemsMap.getOrDefault(purchasedItem, 0) + 1);
        }

        for (Item ingredient : requiredIngredients.keySet()) {
            int requiredQuantity = requiredIngredients.get(ingredient);
            int purchasedQuantity = purchasedItemsMap.getOrDefault(ingredient, 0);

            if (requiredQuantity > purchasedQuantity) {
                int missingQuantity = requiredQuantity - purchasedQuantity;
                missingIngredients.put(ingredient, missingQuantity);
            }
        }

        return missingIngredients;
    }



    public void getChange(float change, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        if (change > money) {
            display.append("Insufficient change available. Please contact maintenance." + "\n");
            return;
        }

        int pesos = (int) change;
        int centavos = Math.round((change - pesos) * 100);

        display.append("\nChange: " + pesos + " pesos" + "\n");

        if (centavos > 0) {
            display.append(centavos + " centavos" + "\n");
        }

        money -= change;
        displayArea.append(display.toString());
    }


    public void collectMoney(float amount, JTextArea displayArea) {
        StringBuilder display = new StringBuilder();
        money += amount;
        display.append("Money collected: " + amount + "\n");
        displayArea.setText(display.toString());
    }

    public void replenishMoney(float amount, JTextArea displayArea) {
        StringBuilder display = new StringBuilder();
        money += amount;
        display.append("Money replenished: " + amount + "\n");
        displayArea.setText(display.toString());
    }

    public void printTransactions(JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        for (Transaction transaction : transactions) {
            display.append("TRANSACTION ID\t:   " + transaction.getID() + "\n");
            display.append("ITEM PURCHASED\t:   " + transaction.getSpecialItem().getName() + "\n");
            display.append("QUANTITY\t:   " + transaction.getQuantity() + "\n");
            display.append("PAYMENT\t:   P" + transaction.getPayment() + "\n");
            display.append("CHANGE\t:   P" + transaction.getChange() + "\n");
            display.append("------------------------\n");
        }

        displayArea.setText(display.toString());

    }

    public float printSales() {
        return totalSales;
    }

    public Slot[] getSlots() {
        return slots;
    }

    private int createID() {
        Random rand = new Random();
        int transactionId = rand.nextInt(100000) + 1;
        return transactionId;
    }

    public List<Item> getUserPurchased()
    {
        return userPurchased;
    }
}
