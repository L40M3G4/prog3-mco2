import javax.swing.*;
import java.io.PrintStream;
import java.util.Scanner;

public class Transaction {
    Scanner input = new Scanner(System.in);

    private int ID;
    private SpecialItem specialItem;
    private Item item;
    private int quantity;
    private float payment;
    private float change;
    private String[] T_History_name = new String[1000];
    private float[][] TransactionHistory = new float[1000][5];
    private JTextArea outputTextArea;

    public Transaction(int ID, Item item, int quantity, float payment, float change) {
        this.ID = ID;
        this.item = item;
        this.quantity = quantity;
        this.payment = payment;
        this.change = change;
    }

    public Transaction(int ID, SpecialItem specialItem, int quantity, float payment, float change) {
        this.ID = ID;
        this.specialItem = specialItem;
        this.quantity = quantity;
        this.payment = payment;
        this.change = change;
    }

    public int getID() {
        return ID;
    }

    public Item getItem() {
        return item;
    }

    public SpecialItem getSpecialItem() {
        return specialItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public float getPayment() {
        return payment;
    }

    public float getChange() {
        return change;
    }

    public void displayTransactionHistory(JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        for (int i = 0; i < TransactionHistory.length; i++) {
            if (TransactionHistory[i][0] == 0) {
                break;
            }
            display.append("Item name: " + T_History_name[i]);
            display.append(", Quantity sold: " + TransactionHistory[i][0]);
            display.append(", Amount: " + TransactionHistory[i][2]);
            display.append(", Total: " + TransactionHistory[i][3]);
            display.append(", All items: " + TransactionHistory[i][4] + "\n");
        }

        displayArea.setText(display.toString());

    }

}
