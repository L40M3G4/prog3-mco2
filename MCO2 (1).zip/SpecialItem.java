import javax.swing.*;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SpecialItem {
    private String name;
    private String code;
    private float calorieCount;
    private float price;
    private boolean unique;
    private String specialIngredient;

    private Map<Item, Integer> ingredients = new HashMap<>();
    private List<String> cookingSteps;


    public SpecialItem(String name, String code, float calorieCount, float price, Item[] itemList, Item[] specialIngredients, int[] quantities, List<String> cookingSteps) {
        this.name = name;
        this.code = code;
        this.calorieCount = calorieCount;
        this.price = price;
        this.unique = true;
        this.specialIngredient = "";
        this.cookingSteps = cookingSteps;


        List<Item> validIngredients = new ArrayList<>();

        for (Item ingredient : specialIngredients) {
            validIngredients.add(ingredient);
        }

        for (Item ingredient : specialIngredients) {
            this.ingredients.put(ingredient, 0);
        }

        for (int i = 0; i < specialIngredients.length; i++) {
            this.ingredients.put(specialIngredients[i], quantities[i]);
        }

        for (Item ingredient : validIngredients) {
            if (!this.ingredients.containsKey(ingredient)) {
                throw new IllegalArgumentException("Ingredient '" + ingredient.getItemName() + "' is not registered.");
            }
        }
    }

    public void displayCookingSteps(JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        for (String step : cookingSteps) {
            display.append("- " + step + "\n");
        }

        displayArea.append(display.toString());

    }


    public void addSpecialIngredient(String specialIngredient) {
        this.specialIngredient = specialIngredient;
    }

    public String getSpecialIngredient() {
        return specialIngredient;
    }

    public Map<Item, Integer> getIngredients() {
        return ingredients;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getCalorieCount() {
        return calorieCount;
    }

    public void setCalorieCount(float calorieCount) {
        this.calorieCount = calorieCount;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public boolean isUnique() {
        return unique;
    }

    public void setUnique(boolean unique) {
        this.unique = unique;
    }

    public boolean containsIngredients(List<Item> itemList) {
        for (Item item : itemList) {
            boolean found = false;
            for (Item ingredient : ingredients.keySet()) {
                if (item.getItemName().equals(ingredient.getItemName())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }
}
