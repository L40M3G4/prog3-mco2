import javax.swing.*;
import java.io.PrintStream;

public class SpecialMaintenance {
    private SVM specialVending;
    public SpecialMaintenance(SVM specialVending) {
        this.specialVending = specialVending;
    }

    public void restockItems(String itemName, JTextArea displayArea) {
        boolean itemFound = false;

        for (int i = 0; i < specialVending.getSlots().length; i++) {
            Slot slot = specialVending.getSlots()[i];
            Item item = slot.getItems();

            if (item != null && item.getItemName().equals(itemName)) {
                slot.setQuantity(10, displayArea);
                itemFound = true;
                break;
            }
        }

        StringBuilder display = new StringBuilder();


        if (itemFound) {
            display.append("Item restocked: " + itemName + "\n");
        } else {
            display.append("Item not found!" + "\n");
        }

        displayArea.setText(display.toString());
    }

    public void setPrice(SpecialItem item, float price, JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        item.setPrice(price);
        display.append("Item: " + item.getName() + " - Price: " + price + "\n");

        displayArea.setText(display.toString());
    }

    public void collectMoney(float amount,  JTextArea displayArea) {

        StringBuilder display = new StringBuilder();


        specialVending.collectMoney(amount, displayArea);
        display.append("Money collected: " + amount + "\n");

        displayArea.setText(display.toString());
    }

    public void replenishMoney(float amount,  JTextArea displayArea) {

        StringBuilder display = new StringBuilder();

        specialVending.replenishMoney(amount, displayArea);
        display.append("Money replenished: " + amount + "\n");

        displayArea.setText(display.toString());

    }
}
