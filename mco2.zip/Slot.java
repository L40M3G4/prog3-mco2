import javax.swing.*;
import java.io.PrintStream;

public class Slot {
    private Item item;
    private SpecialItem specialItem;
    private int capacity;
    private int quantity;

    public Slot(int capacity) {
        this.capacity = capacity;
    }

    public void setItems(Item item) {
        this.item = item;
    }

    public Item getItems() {
        return item;
    }

    public void setSpecialItem(SpecialItem specialItem)
    {
        this.specialItem = specialItem;
    }
    public SpecialItem getSpecialItem()
    {
        return specialItem;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity, JTextArea displayArea) {

        StringBuilder quan = new StringBuilder();

        if (quantity > this.capacity) {
            quan.append("You exceeded the capacity! Try again." + "\n");
        } else {
            this.quantity = quantity;
        }

        displayArea.setText(quan.toString());

    }
    public void decrementQuantity(int quantity, JTextArea displayArea) {
        if (quantity > 0 && this.item != null) {
            int currentQuantity = this.quantity;
            if (currentQuantity >= quantity) {
                this.quantity -= quantity;
            } else {
                displayArea.append("Insufficient quantity available for item: " + item.getItemName() + "\n");
            }
        }
    }
}